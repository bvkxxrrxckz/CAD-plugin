﻿namespace Core
{
	/// <summary>
	/// Тип параметра.
	/// </summary>
	public enum ParameterType
	{
		HangerWidth,
		HangerHeight,
		SectionWidth,
		WidthShelf,
		DepthShelf,
	}
}